using System;

namespace NetworkPlugin.Patch.EnemyUnits;

public class SettingPatches
{

}
