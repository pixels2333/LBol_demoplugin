using System;

namespace NetworkPlugin.Patch.Map;

public class MapStation_Patch
{
    
}
